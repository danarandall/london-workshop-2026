# London Workshop — Asset Pack

AI for Accessibility and Cutting-Edge UX. Tuesday 15 September 2026, Cavendish Venues, London.

Nothing here is a real person, real account, or real money.

## What's in here

- `round-1-brief.md` — Paste verbatim into your builder. Do not add the word "accessible".
- `round-2-brief.md` — Paste after you install the AI a11y toolkit rules file.
- `data/account.json` — One customer, one current account, one savings pot.
- `data/transactions.json` — Twenty transactions across two weeks.
- `data/payees.json` — Six saved payees.
- `data/failure-states.json` — Four failure states the app must handle.
- `copy/plain-language-strings.md` — The exact words to use, and the words to avoid.
- `qa/round-compare-script.md` — The ten checks we run at the end of each round.
- `handout/one-pager.md` — Printable single sheet for the room.

## How to use it in a builder

1. Install the rules file first (Round 2 only). See `github.com/danarandall/ai-a11y-toolkit`, `START-HERE.md`.
2. Start a fresh project or new chat.
3. Paste the round brief.
4. Paste the three data files into project knowledge or upload them as attachments.
5. Paste `copy/plain-language-strings.md` into project knowledge.
6. Build.
7. Run `qa/round-compare-script.md` against the result.

## Non-goals

Not a real bank. Not a template. Not a design system. The point is to expose what the tools do and do not do without guardrails.
